/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author rakes
 */
public class tables {
    public static void main(String[] args)
    {
        Connection con=null;
        Statement st=null;
        
        try
        {
           con=ConnectionProvider.getCon();
           st=con.createStatement();
           
           
          st.executeUpdate("create table users(id int primary key NOT null AUTO_INCREMENT ,name varchar(100),password varchar(100),email varchar(100),contact varchar(100))");
          
          st.executeUpdate("create table book_details(book_id int primary key not NULL AUTO_INCREMENT ,book_name varchar(100),author varchar(100),quantity int )");
          st.executeUpdate("create table student_details(student_id int primary key not NULL AUTO_INCREMENT,student_name varchar(100),contact varchar(13),email varchar(100),course varchar(100),branch varchar(100),address varchar(200),number_of_book int)");
          st.executeUpdate("create table issue_book_details(book_ssue_id int primary key not NULL AUTO_INCREMENT,book_id int,book_name varchar(100),book_author varchar(100),student_id int,student_name varchar(100),student_contact varchar(13),student_email varchar(200),student_course varchar(100),student_branch varchar(100),student_address varchar(200),issue_date date,due_date date,status varchar(100))");
                                                                                                                                                                                                                                                                                                                                                                                  
          JOptionPane.showMessageDialog(null,"Table Create Successfully");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
        finally
        {
             try
        {
            con.close();
            st.close();
        }
        catch(Exception e)
        {}
        }
    }
}
